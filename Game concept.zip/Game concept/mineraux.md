|   |   |   |   |
|---|---|---|---|
|Nom|Aspect|Usage magique|Type dâ€™effet en gameplay|
|Opale|LaitÃ©e, iridescente|Canalisation dâ€™Ã¢mes, divination|AccÃ¨s aux souvenirs, visions, perception cachÃ©e|
|Iridium|MÃ©tal noir lustrÃ©|Stabilisation de portails|RÃ©duit coÃ»t en mana ou stabilise invocations|
|Osmium|TrÃ¨s dense, bleu-argentÃ©|Renforcement structurel|Armures lourdes, buff de dÃ©fense passive|
|Tantale|MÃ©tal bleu sombre|RÃ©sonance magique|RÃ©verbÃ©ration dâ€™attaques magiques (effet miroir)|
|Labradorite|Reflets froids bleus/verts|Illusion, brouillage|Esquive amÃ©liorÃ©e, tÃ©lÃ©portation courte|
|Bismuth|Cristaux multicolores gÃ©omÃ©triques|AltÃ©ration de rÃ©alitÃ©|Mutation du dÃ©cor, distorsion de lâ€™espace ou du temps|
|CÃ©rium|ArgentÃ© brillant|Feu sacrÃ©|DÃ©gÃ¢ts feu pur, lumiÃ¨re anti-spectre|
|NÃ©odyme|Rose-mauve mÃ©tallique|LÃ©vitation, magnÃ©tisme|Attire/repousse objets, ennemis|
|Alexandrite|Vert-rouge changeant|DualitÃ©, choix|Buff ou soin selon dÃ©cision (voie claire/obscure)|
|Lanthane|Blanc-gris avec reflets bleutÃ©s|Amplificateur dâ€™Ã©nergie|Double effets magiques (surcoÃ»t en contrepartie)|
|Dysprosium|MÃ©tal gris-vert|Manipulation de champs invisibles|Boucliers directionnels, ralentissement dâ€™ennemis|
|ChrysobÃ©ryl|Jaune-vert trÃ¨s brillant|ClartÃ© mentale, anticipation|Bonus parade, lecture dâ€™intention ennemie|
|PÃ©ridot|Vert vif, translucide|Croissance, lien Ã  la nature|RÃ©gÃ©nÃ©ration, invocation racines, soins progressifs|
|Zircon|Multicolore dur comme le diamant|Scellement, verrouillage|Verrouillage de pouvoirs ennemis ou de zones magiques|
|Azurite|Bleu profond, veinÃ© de noir|Eau, mÃ©moire fluide|ContrÃ´le de lâ€™eau, illusions liquides|
|Stibine|Noir bleutÃ© avec Ã©clats argentÃ©s|Poison, corruption|MalÃ©dictions, effets toxiques, altÃ©ration longue durÃ©e|
