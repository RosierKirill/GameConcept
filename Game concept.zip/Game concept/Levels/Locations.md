List of locations

Castle of Montflori :
- 20+ rooms and corridors
- constant mobs spawn
- Main story
The city of Florimont



