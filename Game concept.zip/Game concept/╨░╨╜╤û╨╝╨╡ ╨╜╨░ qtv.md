Ось оновлений список аніме, які транслювалися на QTV (раніше — «Куй‑ТВ») в Україні:

  

  

  

  

🛸 Офіційно згадані в описах QTV (2010+)

  

  

- Naruto (Наруто)
- Fullmetal Alchemist (Стальний алхімік)
- Death Note (Тетрадь смерти)
- Neon Genesis Evangelion (Євангеліон)
- Bleach (Бліч)  

  

  

Також були:

  

- Avatar: The Last Airbender
- Robot Chicken
- Futurama (доповідь: старт у 2010, тривали 5–7 сезони)  

  

  

  

  

  

📺 Інші аніме, підтверджені фанатськими колекціями

  

  

Переважно — в період 2010–2013 (дані за 2018 роком): 

  

- Afro Samurai
- Black Blood Brothers
- Strait Jacket
- Gungrave
- D.Gray-man
- Toki wo Kakeru Shoujo
- Devil May Cry
- Elfen Lied
- Ergo Proxy
- Karas
- Cyber City Oedo 808
- Blood+
- Great Teacher Onizuka
- Juubee Ninpuuchou
- Naruto: Shippuuden
- Vampire Hunter D
- Black Lagoon (разом із Black Lagoon: The Second Barrage)
- Soul Eater
- Samurai Champloo
- Trigun
- Hellsing Ultimate
- Yu‑Gi‑Oh! Duel Monsters GX
- Darker than Black
- One Piece
- Shaman King
- Evangelion Movie 1.11: You Are (Not) Alone
- Majo no Takkyuubin (Witch’s Delivery Service)
- Monsuno
- Bakugan Battle Brawlers
- Full Metal Panic! (+ Fumoffu і The Second Raid)
- Vampire Hunter D (2000)
- Sonic X
- Slayers
- Appleseed
- Wonderful Days
- Juuni Kokuki (The Twelve Kingdoms)
- Chobits
- Macross Plus
- Ghost in the Shell: Stand Alone Complex (1 та 2 сезони)
- Hellsing
- Gunslinger Girl
- Last Exile
- Fushigi Yuugi
- Genma Taisen
- Sol Bianca
- Sakura Taisen Movie
- Kaze wo Mita Shounen  
    …і деякі інші — зауважте, що не всі транслювалися одночасно.

  

  

  

  

  

📌 Приклади трансляцій по окремих серіалах:

  

  

- Dragon Ball Z/Super — згадується, що QTV транслював «Dragon Ball» у ранніх 2010‑х (ймовірно, російський дубляж)  
- Futurama — старт 2010‑го року, український дубляж ISP Film  

  

  

  

  

  

📋 Підсумкова таблиця

  

|   |   |
|---|---|
|Аніме|Джерело/Примітка|
|Naruto|QTV згадка|
|Fullmetal Alchemist|QTV згадка|
|Death Note|QTV згадка|
|Neon Genesis Evangelion|QTV згадка|
|Bleach|QTV згадка|
|Dragon Ball (Z/Super)|фан/веб-згадка|
|Futurama|QTV студія дубляжу|
|Afro Samurai, Black Lagoon, Trigun, Elfen Lied, тощо…|фан-підбірка|

  

  

  

Якщо цікавлять конкретні роки трансляцій чи часові слоти — скажіть, я уточню по кожному шоу. Також можу шукати інші, менш відомі серіали.