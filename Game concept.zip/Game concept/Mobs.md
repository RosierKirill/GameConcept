|   |   |   |   |
|---|---|---|---|
|Nom|Inspiration|Comportement|RÃ´le ludique|
|Vourdalak (standard)|Slaves / folklore vampire|Lent, imprÃ©visible, ressuscite sâ€™il nâ€™est pas purgÃ©|Ennemi commun, introduit les mÃ©caniques de corruption|
|Rampeurs de boue|Esprits marÃ©cageux|Surgissent du sol, en groupe|Pression de proximitÃ© dans marÃ©cages|
|PossÃ©dÃ©s des bois|Slaves / forÃªt animÃ©e|Rient, se camouflent dans les arbres|Jump scare, perturbation du rythme|
|Larves de Brama|InventÃ©, liÃ©s Ã  la Porte|Aveugles, rÃ©agissent au son|Encouragent la furtivitÃ© ou le silence|
|Spectres du CimetiÃ¨re|Classiques / folklore chrÃ©tien|Fixes ou Ã  trajectoire prÃ©visible|Zone control, puzzle basÃ© sur la lumiÃ¨re ou chant|
|Domovik inversÃ©|Variante nÃ©gative de burkan|Hurle, se lie Ã  un objet|Ennemis liÃ©s Ã  un lieu prÃ©cis, mÃ©canique de purification|
|Lâ€™Ã‰corcheur dâ€™Ã¢me|Original / esprit torturÃ©|Absorbe les cris des morts|Mini-boss, vulnÃ©rable aux sorts de silence|
|Main-CrÃ¢ne|Type ogre dÃ©formÃ©|Porte sa victime, bondit|Boss secondaire dans le quartier lumineux|
|Lâ€™InvoquÃ©-RÃ©verbÃ¨re|DÃ©mon rituÃ©lique|Semi-immatÃ©riel, liÃ© aux runes au sol|Boss Ã  puzzle, clairiÃ¨re occulte|
|Vyi, the Gazer Demon|Folklore slave direct (Ð’Ñ–Ð¹)|Aveugle, rayon mortel, accompagnÃ© dâ€™ouvre-paupiÃ¨res|Boss final de mission, invocation obligatoire|
