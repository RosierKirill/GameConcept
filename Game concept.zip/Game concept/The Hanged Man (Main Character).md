## Rôle
(Main Character)

## Description
Golem de chair crée par la sorcière Helga lors du rituel de la danse de la vie. Il est composé des corps des guerriers déchus. Il chasse les monstres et accompli diverses missions pour Helga. 

## Apparence
- 1,91 / 91kg
- vieux uniforme usés de l’armée de Montflori, lanterne des âmes, sacoche à la ceinture, grande épée 
- peau pales, runes violettes incandescentes tatouées, un masque métallique couvrant le visage, bandes rituels sur le torse
- humain en apparence 

## Personnalité
- muet, calme, efficace
- une fois retrouvé sa conscience cherche a connaitre son passé et cherche a donner du sens à sa vie 
- il n’a pas peur de la mort car il l’était déjà.

## Histoire
- crée par Helga
- Sa conscience l’éveil et il retrouve des souvenirs sur sa vie d’avant 
- Il a une relation ambiguë avec Helga entre subordination et volonté de se libérer 

## Lieux associés
- Il est en chemin depuis le sud de la Konfederation vers la capitale de Montflori

## Capacités / Pouvoirs / Magie
- force et endurance hors normes, combat de mêlées
- competences spéciales : invoque des Spectres
- Armes utilisées : épée (Oeil d’Opal), Hallebarde( Fleur de Lys), haches (Jumelles)

## Liens narratifs
- Alliés : Bogur, Ayla&Laurene
- Ennemis : General LaPierre, Vyi, Alaric II, 
- Influence sur le héros ou l’histoire : aide et obstacles

## Réplique typique (facultatif)
> *"…"*

## Inspirations (facultatif)
- Références visuelles ou artistiques (darksouls, witcher, devil may cry, assassin’s creed, castelvania, soul eater, jojo, berserk)