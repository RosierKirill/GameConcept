
## Bosses
Konstantin Moroi  
Tursu, The Horror from the Deep  
Vyi, The Gazer Demon  
Alaric II – The King of MontFlori  

## Spectres
Strigoboor – Lapiz Knight  
Velsebor – Golden Mage  
Volkhoboor – Crimson Beast  

## Weapons
Sword – Unnamed  
Greatsword – Eye of Opal  
Halbard – Lys Flower  
War axes – Twins  
Scythe – Soul Taker  

## Characters
The Hanged Man (Main Character)  
Helga the Witch  
Bogur – Burkanian Alchemist  
Ayla & Laurene – Mlyvian blacksmith sisters  
General Charles LaPierre  

## Locations
Konfederation – Eisenwald  
Konfederation – Eisental  
Respublica Liberiae – Porto di Luciarno  
Respublica Liberiae – Sabbia Nera  
MontFlori – Plaines Carmines  
MontFlori – SaintMont  

## Mobs
Vurdalak  
Vurdalak Ranger  
Flying Vurdalak  
Vurdalak Drowner  
Vurdalak Beast  
MontFlori's Soldier  