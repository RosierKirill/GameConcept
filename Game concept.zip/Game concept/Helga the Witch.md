## Rôle
(Main Character / Boss / NPC / Ally / Ennemie...)

## Description
Helga est une sorcière ancienne et puissante. Elle parait comme une jeune femme tres belle. Elle fait partie du clan de sorcières de Montflori qui agissent dans l’ombre afin d’attendre leur objectif grace aux guerriers immortels - les golems de chair.

## Apparence
- 1,67 / 56kg
- longue robe noir, petit chapeau, cheveux noirs bouclés avec quelques mèches rousses, un gant métallique avec des longues griffes
- yeux carmins, peau légèrement bronzé 
- a une apparence humaine mais c’est une sorcière 

## Personnalité
- calme, dominatrice, manipulatrice, cache quelques choses, méfiante
- veux instaurer la grande époque des sorcières après avoir écroulé la société humaine et tué le dernier géant - le roi Alaric II.
- elle a un amour etrange pour sa creation - Le Pendu

## Histoire
- C’est la fille de Khors le dieu du soleil noir, elle a juré loyauté inconditionnelle envers son père et son culte
- création du culte de Khors, écroulement du regne des geants puis des dieux, creation du Pendu
- Le pendu est sa creation et son amour

## Lieux associés
- Où le trouver ?
- Où il agit principalement ?

## Capacités / Pouvoirs / Magie
- Spécialités de combat ou de magie
- Compétences uniques
- Armes utilisées

## Liens narratifs
- Alliés :Le Pendu, Khors
- Ennemis : Alaric II, General LaPierre
- Influence sur le héros ou l’histoire : 

## Réplique typique (facultatif)
> *"Prosterne toi devant ta nouvelle maîtresse "*

## Inspirations (facultatif)
- Références visuelles ou artistiques (les gothic lolita, Yousei Teikoku, Yeneffer Venderberg, Chanteuses de metal Cortney Laplante, filles anime)